# Changelog for HaskellExercises01

## Unreleased changes
