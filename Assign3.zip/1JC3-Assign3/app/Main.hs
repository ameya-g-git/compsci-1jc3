{-# LANGUAGE ExistentialQuantification #-}
module Main where


import Test.QuickCheck

-- | Main Program
main :: IO ()
main = putStrLn "1JC3-Assign3 compiled successfully"
