{-# LANGUAGE ExistentialQuantification #-}
module Main where


import qualified Assign_2 as A2

-- | Main Program
main :: IO ()
main = putStrLn "1JC3-Assign2 compiled successfully"
